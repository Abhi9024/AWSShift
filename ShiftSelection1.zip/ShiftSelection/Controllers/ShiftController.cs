using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using ShiftSelection.BLL.Models;
using ShiftSelection.BLL.Services;
using ShiftSelection.DAL;
using ShiftSelection.DAL.Interfaces;

namespace ShiftSelection.Controllers
{
    public class ShiftController: ControllerBase
    {
        private IRepository<Shift> _shiftRepo;
        private IShiftService _shiftService;

        public ShiftController(IRepository<Shift> repository, IShiftService shiftService)
        {
            _shiftRepo = repository;
            _shiftService = shiftService;
        }
        
        // Get Enabled shifts  --- from service
        [HttpGet]
        [Route("GetEnabledShifts")]
        public string GetEnabledShifts(string id)
        {
           var result = new List<string>();
           try
           {
               var shift = _shiftRepo.FindById(id);
               result = _shiftService.GetEnabledShifts(shift);
               return JsonConvert.SerializeObject(result);
           }
           catch(Exception ex)
           {
                result.Add($"Failed to get Shifts with message: {ex.Message}");
                return JsonConvert.SerializeObject(result);
           }
        }


        // Save shift selection
        [HttpPost]
        [Route("SaveShift")]
        public IActionResult SaveShift([FromBody]Shift shift)
        {
           try
           {
               _shiftRepo.Add(shift);
               return Ok("Shift Saved successfully");
           }
           catch(Exception ex)
           {
               return BadRequest($"Failed to save Shift: {ex.Message}");
           }
        }

        [HttpGet]
        [Route("GetData")]
        public List<Shift> SaveSeedData()
        {
           var data = _shiftRepo.List as List<Shift>;
           return data;
        }
    }
}