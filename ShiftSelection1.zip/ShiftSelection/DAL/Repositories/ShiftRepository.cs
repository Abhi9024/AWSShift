using System;
using System.Collections.Generic;
using System.Linq;
using ShiftSelection.BLL.Models;
using ShiftSelection.BLL.Services;
using ShiftSelection.DAL.Interfaces;

namespace ShiftSelection.DAL.Repositories
{
    public class ShiftRepository<T> : IRepository<T> where T : Shift
    {
        private TableContext _context;

        public ShiftRepository(TableContext context)
        {
            _context = context;
        }
        public IEnumerable<T> List => _context.Shift.Where(s=>s.Id>0).ToList() as List<T>;

        public void Add(T entity)
        {
            _context.Shift.Add(entity);
            _context.SaveChanges();
        }

        public void Delete(T entity)
        {
            _context.Shift.Remove(entity);
            _context.SaveChanges();
        }

        public T FindById(string id) 
        {
            var userId = Guid.Parse(id);
            return  (T) _context.Shift.Where(s=>s.UserId == userId).OrderByDescending(s=>s.ShiftEndTime).FirstOrDefault();
        }

        public void Update(T entity)
        {
            _context.Shift.Update(entity);
            _context.SaveChanges();
        }
    }
}