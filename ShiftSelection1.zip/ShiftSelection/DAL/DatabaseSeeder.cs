using System;
using ShiftSelection.BLL.Models;

namespace ShiftSelection.DAL
{
    public class DatabaseSeeder
    {
        private readonly TableContext _context;
        public DatabaseSeeder(TableContext context)
        {
            _context = context;
        }

        public void Seed()
        {
           var test = new Shift()
           {
               ShiftSelected = "Day",
               IsShiftEnabled = true,
               ShiftStartTime = DateTime.UtcNow,
               AddedDate = DateTime.UtcNow,
               UserId = Guid.NewGuid()
           };
           _context.Shift.Add(test);
           _context.SaveChanges();
        }
    }
}