using System.Collections.Generic;
using ShiftSelection.BLL.Models;

namespace ShiftSelection.BLL.Services
{
    public class ShiftService : IShiftService
    {
        public List<string> GetEnabledShifts(Shift shift)
        {
            var result = new List<string>();
            result.Add(shift.UserId.ToString());
            result.Add("Day");
            result.Add("Noon");
            result.Add("Evening");
            result.Add("Night");
            return result;
        }
    }
}