using System;
using System.Collections.Generic;
using System.Linq;
using ShiftSelection.BLL.Models;
using ShiftSelection.DAL.Interfaces;

namespace ShiftSelection.DAL.Repositories
{
    public class ShiftRepository<T> : IRepository<T> where T : Shift
    {
        private TableContext _context;

        public ShiftRepository(TableContext context)
        {
            _context = context;
        }
        public IEnumerable<T> List => throw new System.NotImplementedException();

        public void Add(T entity)
        {
            _context.Shift.Add(entity);
            _context.SaveChanges();
        }

        public void Delete(T entity)
        {
            _context.Shift.Remove(entity);
            _context.SaveChanges();
        }

        public T FindById(string id) 
        {
            var userId = Guid.Parse(id);
            return  (T) _context.Shift.Where(s=>s.UserId == userId).FirstOrDefault();
        }

        public void Update(T entity)
        {
            _context.Shift.Update(entity);
            _context.SaveChanges();
        }
    }
}