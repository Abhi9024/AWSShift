using Microsoft.AspNetCore.Mvc;
using ShiftSelection.BLL.Models;
using ShiftSelection.DAL.Interfaces;

namespace ShiftSelection.Controllers
{
    public class ShiftController: ControllerBase
    {
        private IRepository<Shift> _shiftRepo;

        public ShiftController(IRepository<Shift> repository)
        {
            _shiftRepo = repository;
        }
        
        // Get Enabled shifts  --- from service
        // Save shift selection
    }
}