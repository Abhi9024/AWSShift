using System;

namespace ShiftSelection.BLL.Models
{
    public class Shift: EntityBase
    {
        public Guid UserId { get; set; }
        public string ShiftSelected { get; set; }
        public bool IsShiftEnabled { get; set; }
        public DateTime ShiftStartTime { get; set; }
        public DateTime ShiftEndTime { get; set; }
        public DateTime UserLoggedInTime { get; set; }
        public DateTime AddedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public virtual Nurse Nurse { get; set; }
    }
}