using System;

namespace ShiftSelection.BLL.Models
{
    public class Nurse:EntityBase
    {
        public Guid UserId { get; set; }
        public int ShiftId { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public DateTime DOB { get; set; }
        public string Gender { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
        public string ZipCode { get; set; }
        public virtual Shift Shift { get; set; }

    }
}