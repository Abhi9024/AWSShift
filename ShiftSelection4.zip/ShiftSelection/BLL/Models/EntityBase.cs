using System.ComponentModel.DataAnnotations;

namespace ShiftSelection.BLL.Models
{
    public abstract class EntityBase
    {
        [Key]
        public int Id { get; set; }
    }
}