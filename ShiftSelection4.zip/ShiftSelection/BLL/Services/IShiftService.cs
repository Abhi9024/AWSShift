using System.Collections.Generic;
using ShiftSelection.BLL.Models;

namespace ShiftSelection.BLL.Services
{
    public interface IShiftService
    {
         List<string> GetEnabledShifts(Shift shift);
    }
}