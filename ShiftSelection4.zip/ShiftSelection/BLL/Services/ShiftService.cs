using System;
using System.Collections.Generic;
using ShiftSelection.BLL.Models;

namespace ShiftSelection.BLL.Services
{
    public class ShiftService : IShiftService
    {
        public List<string> GetEnabledShifts(Shift shift)
        {
            var result = new List<string>();

            //get time
            var dateDiff = DateTime.UtcNow.Date.Day - shift.AddedDate.Date.Day;
            var currentLoggedInTime =  shift.AddedDate.Hour;
            if(dateDiff>=1)
            {
                var currentHour = DateTime.UtcNow.Hour;
                result =  GetEnabledShiftsBasedOnHours(currentHour);
            }
            else
            {
                if(!shift.IsShiftEnabled)
                result =  GetEnabledShiftsBasedOnHours(currentLoggedInTime);
            }
            return result;
        }

        private List<string> GetEnabledShiftsBasedOnHours(int currentLoggedInTime)
        {
            var result = new List<string>();
            //day shift
            if(currentLoggedInTime >6 && currentLoggedInTime < 16)
            {
                result.Add("DAY");
            }
            if(currentLoggedInTime > 14 && currentLoggedInTime < 23)
            {
                result.Add("EVENING");                
            }
            if(currentLoggedInTime > 22 && currentLoggedInTime < 8)
            {
                result.Add("NIGHT");                
            }
            return result;
        }
    }
}