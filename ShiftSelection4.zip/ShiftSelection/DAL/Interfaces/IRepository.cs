using System.Collections.Generic;

namespace ShiftSelection.DAL.Interfaces
{
    public interface IRepository<T>
    {
        T FindById(string id);
        IEnumerable<T> List {get;}
        void Add(T entity);
        void Delete (T entity);
        void Update (T entity);
    }
}