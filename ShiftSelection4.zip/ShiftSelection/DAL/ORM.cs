using JetBrains.Annotations;
using Microsoft.EntityFrameworkCore;
using ShiftSelection.BLL.Models;

namespace ShiftSelection.DAL
{
    public class TableContext : DbContext
    {
        public TableContext(DbContextOptions<TableContext> options) : base(options)
        {
        }
        public DbSet<Shift> Shift { get; set; }
    }
}